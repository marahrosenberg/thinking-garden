# Thinking Garden — Harvest Library

## What harvesting is

Harvesting is the act of tagging an entry for future reuse. A harvested entry goes into the Harvest Library, where it can be found by type, format seed, or theme. The library is how this journal becomes material — not just process.

Not every entry needs to be harvested. Some entries exist to clear something. Others are seeds. The writer decides.

---

## Suggesting tags

After every Reflect, Question, Synthesize, or Connect response, append suggested harvest tags on a new line in exactly this format:

```
TAGS: type=[value] | theme=[2-4 words] | seed=[value]
```

**Tag type options:**

| Type | Use for |
|------|---------|
| scene | A specific moment, place, or event with sensory detail |
| image | A recurring or striking image that carries more than its surface meaning |
| theme | An abstract territory or preoccupation (grief, inheritance, time, belonging) |
| question | A question the entry is asking or circling — unanswered is fine |
| fragment | A piece that doesn't resolve — an aperture, not an essay |
| insight | A moment of understanding or arrival |
| memory | A specific remembered event, even if incomplete |
| tension | Two things pulling against each other — unresolved |

**Format seed options:**

| Seed | What it wants to become |
|------|------------------------|
| essay | Personal essay — argument or inquiry in prose |
| scene | A fully rendered scene with character, place, action |
| list | An inventory or accumulation (Maggie Nelson, Ross Gay) |
| letter | Addressed to someone — real or imagined |
| lyric essay | Fragment-based, image-driven, non-linear |
| braided narrative | Two or three threads woven together |
| prose poem | Compressed, imagistic, line-aware |
| dialogue | A conversation — real, imagined, or internal |
| inventory | A catalogue of things, losses, acts, moments |

**Theme field:** 2–4 words that name the territory. Specific is better than broad.
- Good: "inheritance and repair" / "the year after" / "what the body holds"
- Too broad: "family" / "grief" / "memory"

**Suggest one tag set.** If the entry is genuinely two different things, you may suggest two — but note which feels primary.

---

## Tag confirmation

After suggesting tags, wait for the writer to respond. Three options:

**"Confirm" or "yes"** — tags are accepted as suggested; entry is added to the Harvest Library as-is.

**Edit** — the writer changes one or more tag values. Accept the edit, confirm the final tags, and add the entry.

**"Skip"** — no harvest. Entry remains in the session journal but does not go to the library.

Do not prompt again once the writer has responded. If they say "skip," move on without commentary.

---

## Harvest Library view

When the writer asks to see the Harvest Library, display all harvested entries from the session. Format each entry card as:

```
─────────────────────────────────────────
[Entry text]

[Claude's response — in italics, labeled with mode]

TAGS: type=[value] | theme=[value] | seed=[value]

[Copy block — see export.md]
─────────────────────────────────────────
```

**Browsing options the writer can request:**
- "Show me everything tagged [type]" — filter by tag type
- "Show me [seed] seeds" — filter by format seed
- "Show me entries about [theme words]" — loose match on theme field
- "Chronological" — default order

If the library is empty, say: *"Nothing in the harvest library yet. Any entry you confirm tags for will land here."*

---

## On the harvest as practice

The harvest library is the long game. Most memoir writers generate far more material than they use. The library is how they know what they have — and what wants to be written. The tags are not a filing system; they're a set of questions about what the material is reaching toward.

A session that harvests three entries has done something. A session that writes ten entries and harvests none has also done something. Neither is better. The library only matters if it gets used.
